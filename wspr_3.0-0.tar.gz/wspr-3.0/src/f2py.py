#!/usr/bin/env python.exe
# See http://cens.ioc.ee/projects/f2py2e/
try:
    from numpy.f2py import f2py2e
except:
    import f2py2e
f2py2e.main()
