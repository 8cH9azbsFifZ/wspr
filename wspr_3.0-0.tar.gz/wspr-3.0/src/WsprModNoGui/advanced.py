import g
from tkrep import *

idint=IntVar()
bfofreq=IntVar()
idint=IntVar()
igrid6=IntVar()
isc1=IntVar()
isc1.set(0)
encal=IntVar()
fset=IntVar()
Acal=DoubleVar()
Bcal=DoubleVar()
fset.set(0)
